console.log("page loaded...");

function over(element){
    element.play(); 
    }

    function pauseVideo(element) {
        element.pause();
    }